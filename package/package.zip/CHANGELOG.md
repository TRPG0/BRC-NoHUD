## 1.1.1

- Rewrote the way that other mods' UI elements are shown/hidden.

## 1.1.0

- Now also affects both [Dragsun's](https://thunderstore.io/c/bomb-rush-cyberfunk/p/Dragsun/Speedometer/) and [SoftGoat's](https://thunderstore.io/c/bomb-rush-cyberfunk/p/SoftGoat/Speedometer/) Speedometer mods, and other players' nameplates in SlopCrew.

## 1.0.0

- Initial release.