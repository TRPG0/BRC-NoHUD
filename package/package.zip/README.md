# NoHUD

Toggle the HUD on or off during gameplay by pressing the BackQuote \` key.

The key can be changed by editing `BepInEx\config\NoHUD.cfg`.

Affects regular gameplay and graffiti spraying.